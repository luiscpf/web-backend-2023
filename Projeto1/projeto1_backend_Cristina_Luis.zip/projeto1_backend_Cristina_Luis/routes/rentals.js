var express = require('express');

var mysql = require('mysql');

var router = express.Router();

var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'projeto1_backend'
});


module.exports = router;